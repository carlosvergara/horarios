$(function() {
  $.material.init();
});